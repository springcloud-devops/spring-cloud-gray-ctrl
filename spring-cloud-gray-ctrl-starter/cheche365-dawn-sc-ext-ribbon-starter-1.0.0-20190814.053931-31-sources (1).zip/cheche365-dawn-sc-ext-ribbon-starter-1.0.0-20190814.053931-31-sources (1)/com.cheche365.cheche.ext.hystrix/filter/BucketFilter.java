package com.cheche365.cheche.ext.hystrix.filter;

import com.cheche365.cheche.ext.hystrix.http.BucketEnv;
import com.cheche365.cheche.ext.hystrix.http.BucketEnvHolder;
import com.cheche365.cheche.ext.hystrix.rule.GrayConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class BucketFilter implements Filter {
    private Logger logger = LoggerFactory.getLogger(BucketFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (request instanceof HttpServletRequest) {
            String header = ((HttpServletRequest) request).getHeader(GrayConstant.Gray_Header);
            if(logger.isDebugEnabled()&& !StringUtils.isEmpty(header)){
                logger.debug("Gray Component Filter get Header  :{}={}", GrayConstant.Gray_Header, header);
            }
            BucketEnvHolder.setBucketEnv(new BucketEnv(header));
        }
        chain.doFilter(request, response);
    }
}
