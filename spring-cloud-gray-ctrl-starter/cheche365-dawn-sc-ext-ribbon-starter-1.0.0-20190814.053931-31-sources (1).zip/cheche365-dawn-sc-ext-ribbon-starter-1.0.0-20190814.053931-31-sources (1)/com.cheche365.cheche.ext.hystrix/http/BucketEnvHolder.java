package com.cheche365.cheche.ext.hystrix.http;

import com.alibaba.ttl.TransmittableThreadLocal;

/**
 * 线程变量操作类
 */
public class BucketEnvHolder {

    private static final TransmittableThreadLocal<BucketEnv> bucketEnvs = new TransmittableThreadLocal<>();

    public static  void setBucketEnv(BucketEnv env) {
        bucketEnvs.set(env);
    }

    public static BucketEnv getCurrentBucketEnv() {
        return bucketEnvs.get();
    }

    public static void removeBucketEnv(){bucketEnvs.remove();}


}
