package com.cheche365.cheche.ext.hystrix.http;


/**
 * 线程变量对象
 */
public class BucketEnv {
    /**
     * 灰度调度的标记header
     */
    private String grayHeader;

    public BucketEnv(String grayHeader) {
        this.grayHeader = grayHeader;
    }

    public String getGrayHeader() {
        return grayHeader;
    }
}
