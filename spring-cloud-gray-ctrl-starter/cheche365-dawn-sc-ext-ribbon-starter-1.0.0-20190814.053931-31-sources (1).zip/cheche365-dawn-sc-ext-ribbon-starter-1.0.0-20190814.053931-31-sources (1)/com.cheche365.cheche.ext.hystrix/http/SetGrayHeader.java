package com.cheche365.cheche.ext.hystrix.http;

import org.apache.http.HttpRequest;

public interface SetGrayHeader {

    void addGrayHeader(HttpRequest httpRequest);
}
