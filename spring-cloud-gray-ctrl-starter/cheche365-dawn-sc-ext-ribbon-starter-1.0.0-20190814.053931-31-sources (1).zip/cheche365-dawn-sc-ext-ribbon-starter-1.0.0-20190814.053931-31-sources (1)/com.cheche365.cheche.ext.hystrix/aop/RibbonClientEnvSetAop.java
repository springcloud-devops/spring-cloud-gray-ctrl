package com.cheche365.cheche.ext.hystrix.aop;

import com.google.common.collect.Sets;
import com.netflix.loadbalancer.IRule;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.util.StringUtils;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

@Aspect
//@Component
public class RibbonClientEnvSetAop {


    @Autowired
    private Environment environment;


    private  static  String  DEFAULT_RULE="com.cheche365.cheche.ext.hystrix.rule.GrayRule";
    private  static final String  LB_RULE_CLASSNAME_SUFFIX=".ribbon.NFLoadBalancerRuleClassName";

    private Set<String> LB_SERVER_SET= Sets.newConcurrentHashSet();

    private static  final Properties p = new Properties();

    @Pointcut("execution(* org.springframework.cloud.netflix.ribbon.PropertiesFactory.isSet(..))")
    public void IRulePoint(){}

    //执行方法前的拦截方法
    @Before("IRulePoint()")
    public void doBeforeSetRule(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        if(args!=null&&args.length>=2){
            if(IRule.class.getName().equals(((Class) args[0]).getName())){
                setLbRuleEnv(args[1].toString());
            }
        }
    }

    private void setLbRuleEnv(String clientName) {
        if(LB_SERVER_SET.add(clientName.concat(LB_RULE_CLASSNAME_SUFFIX))){
            String className = this.environment.getProperty("ribbon.NFLoadBalancerRuleClassName");
            if(StringUtils.hasText(className)){
                DEFAULT_RULE=className;
            }
            ConfigurableEnvironment c = (ConfigurableEnvironment) environment;
            p.put(clientName+LB_RULE_CLASSNAME_SUFFIX, DEFAULT_RULE);
            MutablePropertySources propertySources = c.getPropertySources();
            propertySources.addLast(new PropertiesPropertySource("ribbon",p));
        }
    }
}
