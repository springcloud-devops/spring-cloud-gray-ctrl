package com.cheche365.cheche.ext.hystrix.rule;

import com.cheche365.cheche.ext.hystrix.http.BucketEnvHolder;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.loadbalancer.Server;
import com.netflix.loadbalancer.ZoneAvoidanceRule;
import com.netflix.niws.loadbalancer.DiscoveryEnabledServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class GrayRule extends ZoneAvoidanceRule {
    private Logger logger = LoggerFactory.getLogger(GrayRule.class);

    @Override
    public Server choose(Object key) {
        try {
            String version = BucketEnvHolder.getCurrentBucketEnv() == null ? null : BucketEnvHolder.getCurrentBucketEnv().getGrayHeader();
            logger.info("Gray-release：gray header  value is :{}", version);
            if (!StringUtils.isEmpty(version)) {
                List<Server> serverList = this.getLoadBalancer().getReachableServers();
                String appInfo=null;
                if(serverList!=null&&!serverList.isEmpty()){
                    InstanceInfo instanceInfo = ((DiscoveryEnabledServer) serverList.get(0)).getInstanceInfo();
                    appInfo=instanceInfo.getAppName();
                }
                Server grayServer = getGrayServer(serverList);
                //存在灰度实例，判断灰度策略是否满足
                if(grayServer!=null){
                    if (GrayConstant.Gray_Header_VAL.equals(version)) {
                        logger.info("调度灰度服务{}的实例信息为instanceId: {}", appInfo,((DiscoveryEnabledServer) grayServer).getInstanceInfo().getInstanceId());
                        return grayServer;
                    }else{
                        //灰度实例存在，但非灰度策略与用户进来了，只能调度正常的实例。
                        Server randomServer = getRandomServer(serverList);
                        if (randomServer != null) {
                            logger.info("非灰度用户，调度{}正常服务的实例", appInfo);
                            return  randomServer;
                        }
                    }
                }

            }
        } catch (Exception ex) {
            logger.error("灰度选择出现异常！", ex);
        }
        Server choose = super.choose(key);
        return choose;
    }


    public Server getRandomServer(List<Server> serverList) {
        List<Server> servers = new ArrayList<>();
        for (Server server : serverList) {
            InstanceInfo instanceInfo = ((DiscoveryEnabledServer) server).getInstanceInfo();
            Map<String, String> metadata = instanceInfo.getMetadata();
            String metaVersion = metadata.get(GrayConstant.Gray_Header);
            if (GrayConstant.Gray_Header_VAL.equals(metaVersion)) {
                continue;
            }
            servers.add(server);
        }
        if (servers.size() > 0) {
            Random random = new Random();
            return servers.get(random.nextInt(servers.size()));
        }
        return null;
    }


    public Server getGrayServer(List<Server> serverList) {
        for (Server server : serverList) {
            InstanceInfo instanceInfo = ((DiscoveryEnabledServer) server).getInstanceInfo();
            Map<String, String> metadata = instanceInfo.getMetadata();
            String metaVersion = metadata.get(GrayConstant.Gray_Header);
            if (!StringUtils.isEmpty(metaVersion) && metaVersion.equals(GrayConstant.Gray_Header_VAL)) {
                return server;
            }
        }
        return null;

    }
}
