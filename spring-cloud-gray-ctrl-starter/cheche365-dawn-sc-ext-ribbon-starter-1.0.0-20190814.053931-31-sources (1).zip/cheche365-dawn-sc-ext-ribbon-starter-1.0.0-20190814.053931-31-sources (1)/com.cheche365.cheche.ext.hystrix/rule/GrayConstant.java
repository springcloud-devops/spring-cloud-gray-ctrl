package com.cheche365.cheche.ext.hystrix.rule;

public class GrayConstant {
    public static final String  Gray_Header="Cheche-G-Version";
    public static final String  Gray_Header_VAL="2.0";
}


