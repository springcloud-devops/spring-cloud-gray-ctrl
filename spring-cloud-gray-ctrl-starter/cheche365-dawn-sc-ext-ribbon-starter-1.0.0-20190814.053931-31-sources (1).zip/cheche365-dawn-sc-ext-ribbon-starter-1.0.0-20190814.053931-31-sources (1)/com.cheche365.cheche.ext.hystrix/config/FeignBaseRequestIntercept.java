package com.cheche365.cheche.ext.hystrix.config;

import com.cheche365.cheche.ext.hystrix.http.BucketEnv;
import com.cheche365.cheche.ext.hystrix.http.BucketEnvHolder;
import com.cheche365.cheche.ext.hystrix.rule.GrayConstant;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FeignBaseRequestIntercept implements RequestInterceptor {

    private static Logger logger = LoggerFactory.getLogger(FeignBaseRequestIntercept.class);


    @Override
    public void apply(RequestTemplate requestTemplate) {
        try {
            BucketEnv currentBucketEnv = BucketEnvHolder.getCurrentBucketEnv();
            if(currentBucketEnv!=null){
                requestTemplate.header(GrayConstant.Gray_Header,currentBucketEnv.getGrayHeader());
                logger.info("Gray Component FeignInterceptor:header is {}",currentBucketEnv.getGrayHeader());
            }else{
                logger.warn("Gray Header not found ");
            }
        } catch (Exception ex) {
            logger.error("设置请求头出错",ex);
        }
    }
}
