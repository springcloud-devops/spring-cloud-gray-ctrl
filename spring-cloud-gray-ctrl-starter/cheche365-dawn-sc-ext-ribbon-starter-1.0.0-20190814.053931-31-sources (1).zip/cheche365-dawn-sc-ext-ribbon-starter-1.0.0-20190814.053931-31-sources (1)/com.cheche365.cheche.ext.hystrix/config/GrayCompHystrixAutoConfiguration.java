package com.cheche365.cheche.ext.hystrix.config;

import com.cheche365.cheche.ext.hystrix.aop.RibbonClientEnvSetAop;
import com.netflix.hystrix.Hystrix;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnClass({ Hystrix.class })
@EnableConfigurationProperties(HystrixRequestAttributeProperties.class)

public class GrayCompHystrixAutoConfiguration {
    private static Logger logger = LoggerFactory.getLogger(GrayCompHystrixAutoConfiguration.class);
    @Bean
    @ConditionalOnProperty(prefix = "hystrix.request-attribute",name = "enabled",havingValue = "true")
    public GrayCompBucketEnvHystrixStrategy hystrixRequestAutoConfiguration() {
        logger.info("init config HystrixRequestAttributeAutoConfiguration beans...");
        return new GrayCompBucketEnvHystrixStrategy();
    }

    @Bean
    @ConditionalOnProperty(prefix = "hystrix.request-attribute",name = "enabled",havingValue = "true")
    public RibbonClientEnvSetAop getRibbonClientEnvSetAop(){
        logger.info("init  RibbonClientEnvSetAop bean ..");
        return  new RibbonClientEnvSetAop();
    }

}
