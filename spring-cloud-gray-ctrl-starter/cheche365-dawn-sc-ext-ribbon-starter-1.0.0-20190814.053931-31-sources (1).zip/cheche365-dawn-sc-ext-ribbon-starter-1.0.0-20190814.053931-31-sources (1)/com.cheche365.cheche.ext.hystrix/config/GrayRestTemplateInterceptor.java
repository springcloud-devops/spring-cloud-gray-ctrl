package com.cheche365.cheche.ext.hystrix.config;

import com.cheche365.cheche.ext.hystrix.http.BucketEnv;
import com.cheche365.cheche.ext.hystrix.http.BucketEnvHolder;
import com.cheche365.cheche.ext.hystrix.rule.GrayConstant;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

/**
 *  spring restTemplate 组件的灰度拦截器. 项目组可以自行添加拦截器
 */
public class GrayRestTemplateInterceptor  implements ClientHttpRequestInterceptor {
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        BucketEnv currentBucketEnv = BucketEnvHolder.getCurrentBucketEnv();
        if(currentBucketEnv!=null){
            HttpHeaders headers = request.getHeaders();
            headers.add(GrayConstant.Gray_Header,currentBucketEnv.getGrayHeader());
        }
        return execution.execute(request,body);
    }
}
