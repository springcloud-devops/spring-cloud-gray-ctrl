package com.cheche365.cheche.ext.hystrix.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("hystrix.request-attribute")
public class HystrixRequestAttributeProperties {
    /** Enable Hystrix propagate http request and response. Defaults to false. */
    private boolean enabled = false;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }



}
